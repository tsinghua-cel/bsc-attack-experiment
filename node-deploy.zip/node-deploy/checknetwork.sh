#!/usr/bin/env bash

size=$1

for ((i = 0; i < size; i++)); do
./.local/bsc/node0/geth0 attach --datadir ./.local/bsc/node${i} --exec admin.peers.length
done